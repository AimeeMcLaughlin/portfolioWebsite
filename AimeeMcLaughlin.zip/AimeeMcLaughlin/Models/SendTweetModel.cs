﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AimeeMcLaughlin.Models
{
    public class SendTweetModel
    {
        [DisplayName("Enter your tweet here:")] //Specifies the display name for a property, event, or public void method which takes no arguments.
        [Required]
        [DataType(DataType.MultilineText)] //Represents an enumeration of the data types associated with data fields and parameters.
        public string Text { get; set; }
        public string Response { get; set; }
    }
}