﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AimeeMcLaughlin.Models;

namespace AimeeMcLaughlin.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Portfolio()
        {
            return View();
        }

        public ActionResult Education()
        {
            return View();
        }

        public ActionResult Contact()
        {
            
            ViewBag.theMessage = "Want to get in contact, send me a message!";

            return View();
        }

        [HttpPost]
        public ActionResult Contact(string message)
        {
            //TODO send message
            ViewBag.theMessage = "Thanks,I've received your message";

            return View();
        }

	}
}