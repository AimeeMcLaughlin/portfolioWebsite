﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LinqToTwitter;

namespace AimeeMcLaughlin.Controllers
{
    public class twitterAuthController : Controller
    {
        //
        // GET: /twitterAuth/
        public ActionResult News()
        {
            return View();
        }
	}
}