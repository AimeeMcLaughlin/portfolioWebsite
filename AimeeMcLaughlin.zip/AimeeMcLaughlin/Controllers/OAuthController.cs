﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LinqToTwitter;
using System.Configuration;
using System.Threading.Tasks;
using AimeeMcLaughlin.Models;


namespace AimeeMcLaughlin.Controllers
{
    public class OAuthController : AsyncController
    {
        
        // GET: /twitterAuth/
        public async Task<ActionResult> BeginAsync()
        {
            var auth = new MvcAuthorizer
            {
                //credential store will basically create a login session for the user
                CredentialStore = new SessionStateCredentialStore
                {
                    ConsumerKey = ConfigurationManager.AppSettings["consumerKey"],
                    ConsumerSecret = ConfigurationManager.AppSettings["consumerSecret"]
                }
            };

            string twitterCallbackUrl = Request.Url.ToString().Replace("Begin", "Complete");
            return await auth.BeginAuthorizationAsync(new Uri(twitterCallbackUrl));
        }


        public async Task<ActionResult> CompleteAsync()
        {
            var auth = new MvcAuthorizer
            {
                CredentialStore = new SessionStateCredentialStore()
            };

            await auth.CompleteAuthorizeAsync(Request.Url);


            var credentials = auth.CredentialStore;
            string oauthToken = credentials.OAuthToken;
            string oauthTokenSecret = credentials.OAuthTokenSecret;
            string screenName = credentials.ScreenName;
            ulong userID = credentials.UserID;

            return RedirectToAction("News", "Home");
        }
        /*
        [HttpGet]
        public ActionResult getTweets(ViewTweetsModel model)
        {
            return View();
        }

        //exception handling needs be added if use isn't authenticated!
        [HttpPost]
        [ActionName("Tweet")]
        public async Task<ActionResult> postToTwitter(SendTweetModel model)
        {
            var auth = new MvcAuthorizer
            {
                CredentialStore = new SessionStateCredentialStore()
            };

            var ctx = new TwitterContext(auth);

            Status responseTweet = await ctx.TweetAsync(model.Text);

            var responseTweetVM = new SendTweetModel
            {
                Text = "Testing async LINQ to Twitter in MVC - " + DateTime.Now.ToString(),
                Response = "Tweet successful! Response from Twitter: " + responseTweet.Text
            };

            return View(responseTweetVM);
        }

        */
       
	}
}