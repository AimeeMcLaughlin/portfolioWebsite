﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LinqToTwitter;
using System.Configuration;
using System.Threading.Tasks;
using AimeeMcLaughlin.Models;


namespace AimeeMcLaughlin.Controllers
{
    public class TwitterController : Controller
    {
        
        // GET: /twitterAuth/
        public async Task<ActionResult> BeginAsync()
        {
            var auth = new MvcAuthorizer
            {
                //credential store will basically create a login session for the user
                CredentialStore = new SessionStateCredentialStore
                {
                    ConsumerKey = ConfigurationManager.AppSettings["Z62d1OEqoCKBRArJurHphtAHt"],
                    ConsumerSecret = ConfigurationManager.AppSettings["SXHMYeR3VRAs2kHB0wm8tUbYEKuG2BjzDqXa5M9uJsfrbeThGm"]
                }
            };

            string twitterCallbackUrl = Request.Url.ToString().Replace("Begin", "Complete");
            return await auth.BeginAuthorizationAsync(new Uri(twitterCallbackUrl));
        }


        public async Task<ActionResult> CompleteAsync()
        {
            var auth = new MvcAuthorizer
            {
                CredentialStore = new SessionStateCredentialStore()
            };

            await auth.CompleteAuthorizeAsync(Request.Url);

            // This is how you access credentials after authorization.
            // The oauthToken and oauthTokenSecret do not expire.
            // You can use the userID to associate the credentials with the user.
            // You can save credentials any way you want - database, 
            //   isolated storage, etc. - it's up to you.
            // You can retrieve and load all 4 credentials on subsequent 
            //   queries to avoid the need to re-authorize.
            // When you've loaded all 4 credentials, LINQ to Twitter will let 
            //   you make queries without re-authorizing.
            //
            //var credentials = auth.CredentialStore;
            //string oauthToken = credentials.OAuthToken;
            //string oauthTokenSecret = credentials.OAuthTokenSecret;
            //string screenName = credentials.ScreenName;
            //ulong userID = credentials.UserID;
            //

            return RedirectToAction("News", "Home");
        }

        [HttpGet]
        public ActionResult getTweets(ViewTweetsModel model)
        {
            return View();
        }

        //exception handling needs be added if use isn't authenticated!
        [HttpPost]
        [ActionName("Tweet")]
        public async Task<ActionResult> postToTwitter(SendTweetModel model)
        {
            var auth = new MvcAuthorizer
            {
                CredentialStore = new SessionStateCredentialStore()
            };

            var ctx = new TwitterContext(auth);

            Status responseTweet = await ctx.TweetAsync(model.Text);

            var responseTweetVM = new SendTweetModel
            {
                Text = "Testing async LINQ to Twitter in MVC - " + DateTime.Now.ToString(),
                Response = "Tweet successful! Response from Twitter: " + responseTweet.Text
            };

            return View(responseTweetVM);
        }


       
	}
}